import React from "react";
import "./ProductsList.scss";

export const ProductsList = () => {
  const products = [];

  // Zadanie
  // https://dummyjson.com/products
  // fetch
  // wykonaj request pod podany endpoint
  // zweryfikuj response w konsoli
  // zapisz dane z responsu do satanu lokalnego lub stanu w kontekście

  console.log(products);

  return (
    <article className="products-list-container">
      {/* 
        POBRANĄ LISTĘ PRODUKTÓW WYŚWIETL ZA POMOCĄ FUNCKJI .MAP DOSTĘPNEJ NA TABLICACH
        UŻYJ KOMPONENTU Product.js do wysweitlania produktów 

        w sytuacji gdy nie ma produktów (pusta tablica/obłsuga empty statu) wyświetl stosowny komunikat
      */}
    </article>
  );
};
