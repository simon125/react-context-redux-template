import React from "react";

export const Header = () => {
  return (
    <article>
      <h1>Witaj w sklepie internetowym 😱 Alledrogo 😱</h1>
      <p>
        Na naszej stronie znajdziesz parę produktów które możesz kupić. Dla
        ciekawskich ten sklep jest stworzony w reakcie i reduxie
      </p>
    </article>
  );
};
