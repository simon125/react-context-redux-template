import React from "react";

import "./SelectedProducts.scss";

export const SelectedProducts = () => {
  /**
   * policz cene wszystkich produktów w koszyku
   * uwzględnij też wybraną ilość produktów
   */

  return <article>Koszyk, tylko trochę pusty ...</article>;
};
